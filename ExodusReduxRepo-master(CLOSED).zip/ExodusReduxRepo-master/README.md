# Exodus Redux and LambdaScrapers
## **Addon and Scraper Module for Exodus based add ons.**
